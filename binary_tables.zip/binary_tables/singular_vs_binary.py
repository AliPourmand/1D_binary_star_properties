##goal: to visually plot my results
##and see whether singular and binary disagree or not
import scipy.interpolate
import numpy as np

      
lnq1=np.arange(-6,-2, 0.25)
lnq2=np.arange(-2,2, 0.05)
lnq3=np.arange(2,5.1, 0.25)
lnq12=np.append(lnq1,lnq2)
lnq=np.append(lnq12,lnq3)


print(lnq)
q=10**lnq
n_q=len(q)
print(n_q)

n_xi=600
print(q)
lnq_string=[]

for i in range(n_q):
    lnq_string.append(str("{:.3f}".format(float(lnq[i]))))
    print(lnq_string[i])
print(lnq_string)

data = np.zeros((n_xi,14))

for j in range(n_q):
    
    data = np.zeros((n_xi,14))

    print (lnq_string[j])
    file_location= '..//from_cedar/lq='+lnq_string[j]+'_ns600_np=4001_nt=2001_ls=1_le=600.dat'
    data1 = np.loadtxt(file_location)
    
    data[:,:8] = data1[:,:]
    
    file_location= '..//from_cedar/l1plane/lq='+lnq_string[j]+'_ns600_L1.dat'
    data2 = np.loadtxt(file_location)
    if lnq[j] < 2.6:
        
        data[:,8:] = data2[:,1:]
        


    np.savetxt('bin_props_full_logq='+lnq_string[j]+'.dat',data, fmt='%s', newline='\n')

        


            


            



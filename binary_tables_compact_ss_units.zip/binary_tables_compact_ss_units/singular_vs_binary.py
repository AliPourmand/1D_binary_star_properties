##goal: to visually plot my results
##and see whether singular and binary disagree or not
import scipy.interpolate
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D


      
lnq1=np.arange(-6,-2, 0.25)
lnq2=np.arange(-2,2, 0.05)
lnq3=np.arange(2,5.1, 0.25)
lnq12=np.append(lnq1,lnq2)
lnq=np.append(lnq12,lnq3)


print(lnq)
q=10**lnq
n_q=len(q)
print(n_q)

n_xi=600

data = np.zeros((n_xi,5))

print(q)
lnq_string=[]

for i in range(n_q):
    lnq_string.append(str("{:.3f}".format(float(lnq[i]))))
    print(lnq_string[i])
print(lnq_string)

for j in range(n_q):
    
    file_location= '..//binary_tables/bin_props_full_logq='+lnq_string[j]+'.dat'
    old_data = np.loadtxt(file_location)



    R=old_data[:,4]
    
    data[:,0] = R
    xi_sing = 2*(q[j])/((1+q[j])*R)

    xi=old_data[:,3]/xi_sing
    data[:,1] = xi
  
    g_sing = 2*(q[j])/((1+q[j])*R**2)
    
    g_binary=old_data[:,5]/g_sing
    
    data[:,2]=g_binary
    
    g_lplane=old_data[:,12]/g_sing
    data[:,3]=g_lplane
    

    A_lplane=old_data[:,8]
    data[:,4]=A_lplane

    np.savetxt('binary_props_logq='+lnq_string[j]+'.dat',data, fmt='%s', newline='\n')

        


            


            


